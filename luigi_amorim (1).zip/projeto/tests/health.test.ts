import test from 'node:test';
import assert from 'node:assert/strict';

process.env.DATABASE_URL ??= 'mysql://root:root@localhost:3306/atividade_api';

const { buildApp } = await import('../src/app.js');

test('GET /health deve retornar status ok', async () => {
  const app = buildApp();
  const response = await app.inject({ method: 'GET', url: '/health' });
  assert.equal(response.statusCode, 200);
  assert.equal(response.json().status, 'ok');
  await app.close();
});
