import { asc, eq, sql } from 'drizzle-orm';
import { FastifyPluginAsync } from 'fastify';
import { cidades, empresas, ufs } from '../../db/schema.js';
import { newId } from '../../utils/uuid.js';
import { BadRequestError, NotFoundError } from '../../utils/errors.js';
import { paginated, paginationQuery, uuidParam } from '../common.js';

const body={type:'object',required:['ufId','nome'],properties:{ufId:{type:'string',minLength:36,maxLength:36},nome:{type:'string',minLength:2,maxLength:150}}} as const;
export const registerCidadeRoutes: FastifyPluginAsync=async(app)=>{
  app.post('/',{schema:{tags:['Cidades'],body,response:{201:{type:'object'}}}},async(req,reply)=>{
    const b=req.body as {ufId:string;nome:string}; const [uf]=await app.db.select().from(ufs).where(eq(ufs.id,b.ufId)); if(!uf) throw new BadRequestError('ufId informado não existe.');
    const id=newId(); await app.db.insert(cidades).values({id,ufId:b.ufId,nome:b.nome.trim()}); const [row]=await app.db.select().from(cidades).where(eq(cidades.id,id)); return reply.status(201).send(row);
  });
  app.get('/',{schema:{tags:['Cidades'],querystring:paginationQuery}},async(req)=>{const {page=1,limit=10}=req.query as {page?:number;limit?:number};const p=Math.max(1,page),l=Math.min(100,Math.max(1,limit));const data=await app.db.select().from(cidades).orderBy(asc(cidades.nome)).limit(l).offset((p-1)*l);const [{total}]=await app.db.select({total:sql<number>`count(*)`}).from(cidades);return paginated(data,p,l,Number(total));});
  app.get('/:id',{schema:{tags:['Cidades'],params:uuidParam}},async(req)=>{const {id}=req.params as {id:string};const [row]=await app.db.select().from(cidades).where(eq(cidades.id,id));if(!row)throw new NotFoundError('Cidade');return row;});
  app.get('/:id/empresas',{schema:{tags:['Cidades'],params:uuidParam,querystring:paginationQuery}},async(req)=>{const {id}=req.params as {id:string};const [city]=await app.db.select().from(cidades).where(eq(cidades.id,id));if(!city)throw new NotFoundError('Cidade');const {page=1,limit=10}=req.query as {page?:number;limit?:number};const p=Math.max(1,page),l=Math.min(100,Math.max(1,limit));const data=await app.db.select().from(empresas).where(eq(empresas.cidadeId,id)).limit(l).offset((p-1)*l);const [{total}]=await app.db.select({total:sql<number>`count(*)`}).from(empresas).where(eq(empresas.cidadeId,id));return paginated(data,p,l,Number(total));});
  app.put('/:id',{schema:{tags:['Cidades'],params:uuidParam,body}},async(req)=>{const {id}=req.params as {id:string};const b=req.body as {ufId:string;nome:string};const [uf]=await app.db.select().from(ufs).where(eq(ufs.id,b.ufId));if(!uf)throw new BadRequestError('ufId informado não existe.');const r=await app.db.update(cidades).set({ufId:b.ufId,nome:b.nome.trim()}).where(eq(cidades.id,id));if(r[0].affectedRows===0)throw new NotFoundError('Cidade');const [row]=await app.db.select().from(cidades).where(eq(cidades.id,id));return row;});
  app.delete('/:id',{schema:{tags:['Cidades'],params:uuidParam}},async(req,reply)=>{const {id}=req.params as {id:string};const r=await app.db.delete(cidades).where(eq(cidades.id,id));if(r[0].affectedRows===0)throw new NotFoundError('Cidade');return reply.status(204).send();});
};
