import { eq, sql } from 'drizzle-orm';
import { FastifyPluginAsync } from 'fastify';
import { ufs } from '../../db/schema.js';
import { newId } from '../../utils/uuid.js';
import { NotFoundError } from '../../utils/errors.js';
import { paginated, paginationQuery, uuidParam } from '../common.js';

export const registerUfRoutes: FastifyPluginAsync = async (app) => {
  app.post('/', { schema: { tags: ['UFs'], body: { type: 'object', required: ['sigla','nome'], properties: { sigla: { type:'string', minLength:2, maxLength:2 }, nome:{type:'string',minLength:2,maxLength:100} } }, response:{201:{type:'object'}} } }, async (request, reply) => {
    const body = request.body as { sigla:string; nome:string };
    const id = newId();
    await app.db.insert(ufs).values({ id, sigla: body.sigla.toUpperCase(), nome: body.nome.trim() });
    const [created] = await app.db.select().from(ufs).where(eq(ufs.id,id));
    return reply.status(201).send(created);
  });

  app.get('/', { schema:{tags:['UFs'],querystring:paginationQuery} }, async (request) => {
    const { page=1, limit=10 } = request.query as {page?:number;limit?:number};
    const p=Math.max(1,page), l=Math.min(100,Math.max(1,limit));
    const data=await app.db.select().from(ufs).limit(l).offset((p-1)*l).orderBy(ufs.nome);
    const [{total}]=await app.db.select({total:sql<number>`count(*)`}).from(ufs);
    return paginated(data,p,l,Number(total));
  });

  app.get('/:id', {schema:{tags:['UFs'],params:uuidParam}}, async (request) => {
    const {id}=request.params as {id:string};
    const [row]=await app.db.select().from(ufs).where(eq(ufs.id,id));
    if(!row) throw new NotFoundError('UF');
    return row;
  });

  app.put('/:id',{schema:{tags:['UFs'],params:uuidParam,body:{type:'object',required:['sigla','nome'],properties:{sigla:{type:'string',minLength:2,maxLength:2},nome:{type:'string',minLength:2,maxLength:100}}}}},async(request)=>{
    const {id}=request.params as {id:string}; const body=request.body as {sigla:string;nome:string};
    const result=await app.db.update(ufs).set({sigla:body.sigla.toUpperCase(),nome:body.nome.trim()}).where(eq(ufs.id,id));
    if(result[0].affectedRows===0) throw new NotFoundError('UF');
    const [row]=await app.db.select().from(ufs).where(eq(ufs.id,id)); return row;
  });

  app.delete('/:id',{schema:{tags:['UFs'],params:uuidParam}},async(request,reply)=>{
    const {id}=request.params as {id:string}; const result=await app.db.delete(ufs).where(eq(ufs.id,id));
    if(result[0].affectedRows===0) throw new NotFoundError('UF');
    return reply.status(204).send();
  });
};
