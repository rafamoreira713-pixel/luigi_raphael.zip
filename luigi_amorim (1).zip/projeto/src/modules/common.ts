export const uuidParam = {
  type: 'object',
  required: ['id'],
  properties: { id: { type: 'string', minLength: 36, maxLength: 36 } },
} as const;

export const paginationQuery = {
  type: 'object',
  properties: {
    page: { type: 'integer', minimum: 1, default: 1 },
    limit: { type: 'integer', minimum: 1, maximum: 100, default: 10 },
  },
} as const;

export function paginated<T>(data: T[], page: number, limit: number, total: number) {
  return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
}
