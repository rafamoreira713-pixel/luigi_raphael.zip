import 'dotenv/config';

type NodeEnv = 'development' | 'test' | 'production';

function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Variável de ambiente obrigatória não definida: ${name}`);
  return value;
}

export const env = {
  DATABASE_URL: required('DATABASE_URL'),
  HOST: process.env.HOST ?? '0.0.0.0',
  PORT: Number(process.env.PORT ?? 3333),
  NODE_ENV: (process.env.NODE_ENV ?? 'development') as NodeEnv,
  CORS_ORIGIN: process.env.CORS_ORIGIN ?? '*',
} as const;

if (!Number.isInteger(env.PORT) || env.PORT < 1 || env.PORT > 65535) {
  throw new Error('PORT deve ser um número inteiro entre 1 e 65535.');
}
