import Fastify from 'fastify';
import security from './plugins/security.js';
import swagger from './plugins/swagger.js';
import database from './plugins/database.js';
import errors from './plugins/errors.js';
import { registerUfRoutes } from './modules/ufs/routes.js';
import { registerCidadeRoutes } from './modules/cidades/routes.js';
import { registerEmpresaRoutes } from './modules/empresas/routes.js';
import { registerCategoriaRoutes } from './modules/categorias/routes.js';
import { registerItemRoutes } from './modules/itens/routes.js';
import { registerPratoRoutes } from './modules/pratos/routes.js';
import { registerPratoItemRoutes } from './modules/prato-itens/routes.js';

export function buildApp() {
  const app = Fastify({ logger: true });

  app.register(security);
  app.register(swagger);
  app.register(database);
  app.register(errors);

  app.get('/health', {
    schema: {
      tags: ['Health'],
      response: { 200: { type: 'object', properties: { status: { type: 'string' }, timestamp: { type: 'string' } } } },
    },
  }, async () => ({ status: 'ok', timestamp: new Date().toISOString() }));

  app.register(registerUfRoutes, { prefix: '/api/v1/ufs' });
  app.register(registerCidadeRoutes, { prefix: '/api/v1/cidades' });
  app.register(registerEmpresaRoutes, { prefix: '/api/v1/empresas' });
  app.register(registerCategoriaRoutes, { prefix: '/api/v1/categorias' });
  app.register(registerItemRoutes, { prefix: '/api/v1/itens' });
  app.register(registerPratoRoutes, { prefix: '/api/v1/pratos' });
  app.register(registerPratoItemRoutes, { prefix: '/api/v1/prato-itens' });

  return app;
}
