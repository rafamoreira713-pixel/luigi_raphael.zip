export type Pagination = {
  page: number;
  limit: number;
  offset: number;
};

export function pagination(page = 1, limit = 10): Pagination {
  const normalizedPage = Math.max(1, Math.floor(page));
  const normalizedLimit = Math.min(100, Math.max(1, Math.floor(limit)));
  return {
    page: normalizedPage,
    limit: normalizedLimit,
    offset: (normalizedPage - 1) * normalizedLimit,
  };
}
