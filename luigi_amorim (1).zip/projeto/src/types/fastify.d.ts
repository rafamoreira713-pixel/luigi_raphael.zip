import 'fastify';

declare module 'fastify' {
  interface FastifyInstance {
    db: import('drizzle-orm/mysql2').MySql2Database<typeof import('../db/schema.js')>;
  }
}
