import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';
import { env } from '../config/env.js';
import * as schema from './schema.js';

export const pool = mysql.createPool(env.DATABASE_URL);
export const db = drizzle({ client: pool, schema, mode: 'default' });

export async function closeDatabase(): Promise<void> {
  await pool.end();
}
