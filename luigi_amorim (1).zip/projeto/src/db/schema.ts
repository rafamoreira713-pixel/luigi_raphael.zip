import { relations } from 'drizzle-orm';
import {
  boolean,
  decimal,
  index,
  mysqlTable,
  primaryKey,
  text,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/mysql-core';

const uuid = () => varchar({ length: 36 });

export const ufs = mysqlTable(
  'ufs',
  {
    id: uuid().primaryKey(),
    sigla: varchar({ length: 2 }).notNull(),
    nome: varchar({ length: 100 }).notNull(),
  },
  (table) => [uniqueIndex('ufs_sigla_unique').on(table.sigla)],
);

export const cidades = mysqlTable(
  'cidades',
  {
    id: uuid().primaryKey(),
    ufId: uuid().notNull().references(() => ufs.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    nome: varchar({ length: 150 }).notNull(),
  },
  (table) => [index('cidades_uf_id_idx').on(table.ufId)],
);

export const empresas = mysqlTable(
  'empresas',
  {
    id: uuid().primaryKey(),
    cidadeId: uuid().notNull().references(() => cidades.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    nome: varchar({ length: 150 }).notNull(),
    cnpj: varchar({ length: 14 }),
    ativo: boolean().notNull().default(true),
  },
  (table) => [index('empresas_cidade_id_idx').on(table.cidadeId), uniqueIndex('empresas_cnpj_unique').on(table.cnpj)],
);

export const categorias = mysqlTable(
  'categorias',
  {
    id: uuid().primaryKey(),
    empresaId: uuid().notNull().references(() => empresas.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    nome: varchar({ length: 100 }).notNull(),
  },
  (table) => [index('categorias_empresa_id_idx').on(table.empresaId)],
);

export const itens = mysqlTable(
  'itens',
  {
    id: uuid().primaryKey(),
    empresaId: uuid().notNull().references(() => empresas.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    categoriaId: uuid().notNull().references(() => categorias.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    nome: varchar({ length: 150 }).notNull(),
    preco: decimal({ precision: 10, scale: 2 }).notNull(),
    ativo: boolean().notNull().default(true),
  },
  (table) => [index('itens_empresa_id_idx').on(table.empresaId), index('itens_categoria_id_idx').on(table.categoriaId)],
);

export const pratos = mysqlTable(
  'pratos',
  {
    id: uuid().primaryKey(),
    empresaId: uuid().notNull().references(() => empresas.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    nome: varchar({ length: 150 }).notNull(),
    descricao: text(),
    preco: decimal({ precision: 10, scale: 2 }).notNull(),
    ativo: boolean().notNull().default(true),
  },
  (table) => [index('pratos_empresa_id_idx').on(table.empresaId)],
);

export const pratoItens = mysqlTable(
  'prato_itens',
  {
    id: uuid().primaryKey(),
    pratoId: uuid().notNull().references(() => pratos.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    itemId: uuid().notNull().references(() => itens.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
  },
  (table) => [
    index('prato_itens_prato_id_idx').on(table.pratoId),
    index('prato_itens_item_id_idx').on(table.itemId),
    uniqueIndex('prato_itens_prato_item_unique').on(table.pratoId, table.itemId),
  ],
);

export const ufsRelations = relations(ufs, ({ many }) => ({ cidades: many(cidades) }));
export const cidadesRelations = relations(cidades, ({ one, many }) => ({
  uf: one(ufs, { fields: [cidades.ufId], references: [ufs.id] }),
  empresas: many(empresas),
}));
export const empresasRelations = relations(empresas, ({ one, many }) => ({
  cidade: one(cidades, { fields: [empresas.cidadeId], references: [cidades.id] }),
  categorias: many(categorias),
  itens: many(itens),
  pratos: many(pratos),
}));
export const categoriasRelations = relations(categorias, ({ one, many }) => ({
  empresa: one(empresas, { fields: [categorias.empresaId], references: [empresas.id] }),
  itens: many(itens),
}));
export const itensRelations = relations(itens, ({ one, many }) => ({
  empresa: one(empresas, { fields: [itens.empresaId], references: [empresas.id] }),
  categoria: one(categorias, { fields: [itens.categoriaId], references: [categorias.id] }),
  pratoItens: many(pratoItens),
}));
export const pratosRelations = relations(pratos, ({ one, many }) => ({
  empresa: one(empresas, { fields: [pratos.empresaId], references: [empresas.id] }),
  pratoItens: many(pratoItens),
}));
export const pratoItensRelations = relations(pratoItens, ({ one }) => ({
  prato: one(pratos, { fields: [pratoItens.pratoId], references: [pratos.id] }),
  item: one(itens, { fields: [pratoItens.itemId], references: [itens.id] }),
}));

export type Uf = typeof ufs.$inferSelect;
export type Cidade = typeof cidades.$inferSelect;
export type Empresa = typeof empresas.$inferSelect;
export type Categoria = typeof categorias.$inferSelect;
export type Item = typeof itens.$inferSelect;
export type Prato = typeof pratos.$inferSelect;
export type PratoItem = typeof pratoItens.$inferSelect;
