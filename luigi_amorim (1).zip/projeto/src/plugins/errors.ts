import fp from 'fastify-plugin';
import { BadRequestError, ConflictError, NotFoundError } from '../utils/errors.js';

export default fp(async (app) => {
  app.setErrorHandler((error, request, reply) => {
    request.log.error({ err: error }, 'request_error');

    if (error.validation) {
      return reply.status(400).send({
        error: 'VALIDATION_ERROR',
        message: 'Dados da requisição inválidos.',
        details: error.validation,
      });
    }

    if (error instanceof NotFoundError) {
      return reply.status(404).send({ error: 'NOT_FOUND', message: error.message });
    }

    if (error instanceof ConflictError) {
      return reply.status(409).send({ error: 'CONFLICT', message: error.message });
    }

    if (error instanceof BadRequestError) {
      return reply.status(400).send({ error: 'BAD_REQUEST', message: error.message });
    }

    return reply.status(500).send({
      error: 'INTERNAL_SERVER_ERROR',
      message: 'Ocorreu um erro interno no servidor.',
    });
  });
});
