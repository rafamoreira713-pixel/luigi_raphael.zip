import fp from 'fastify-plugin';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';

export default fp(async (app) => {
  await app.register(swagger, {
    openapi: {
      openapi: '3.0.3',
      info: {
        title: 'API Restaurante — Atividade 001',
        description: 'API REST com Fastify, TypeScript e Drizzle ORM baseada no modelo ER da atividade.',
        version: '1.0.0',
      },
      tags: [
        { name: 'UFs', description: 'Unidades federativas' },
        { name: 'Cidades', description: 'Cidades vinculadas a UFs' },
        { name: 'Empresas', description: 'Empresas vinculadas a cidades' },
        { name: 'Categorias', description: 'Categorias de itens por empresa' },
        { name: 'Itens', description: 'Itens comercializados pelas empresas' },
        { name: 'Pratos', description: 'Pratos compostos por itens' },
        { name: 'Prato Itens', description: 'Relacionamento N:N entre pratos e itens' },
      ],
    },
  });

  await app.register(swaggerUi, { routePrefix: '/docs' });
});
