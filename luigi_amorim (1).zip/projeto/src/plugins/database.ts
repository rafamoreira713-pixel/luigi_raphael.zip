import fp from 'fastify-plugin';
import { db } from '../db/client.js';

export default fp(async (app) => {
  app.decorate('db', db);

  app.addHook('onClose', async () => {
    const { closeDatabase } = await import('../db/client.js');
    await closeDatabase();
  });
});
