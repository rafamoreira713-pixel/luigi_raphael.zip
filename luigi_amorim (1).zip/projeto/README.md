# API Restaurante — Fastify + TypeScript + Drizzle ORM

Projeto acadêmico desenvolvido a partir do modelo ER fornecido na atividade. A API implementa CRUDL para **UFs, cidades, empresas, categorias, itens, pratos e prato_itens**, além de endpoints de relacionamento para demonstrar o uso do Drizzle ORM em um domínio relacional.

## Stack

- Node.js 20+
- Fastify 5
- TypeScript 5
- Drizzle ORM + MySQL2
- MySQL 8+
- TypeBox para validação e tipagem de schemas
- Swagger/OpenAPI para documentação interativa
- Helmet e CORS para configuração HTTP básica

## Arquitetura

```text
src/
├── config/       # Configuração e variáveis de ambiente
├── db/           # Conexão, schema e relações Drizzle
├── modules/      # Rotas e regras de cada recurso
├── plugins/      # Plugins Fastify (Swagger, segurança, etc.)
├── utils/        # Respostas, UUID e tratamento de erros
└── server.ts     # Bootstrap da aplicação
```

## 1. Preparar o banco

Crie um banco MySQL:

```sql
CREATE DATABASE atividade_api CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Copie `.env.example` para `.env` e ajuste `DATABASE_URL`.

## 2. Instalar dependências

```bash
npm install
```

## 3. Criar/aplicar migrations

```bash
npm run db:generate
npm run db:migrate
```

Para desenvolvimento rápido também é possível usar:

```bash
npm run db:push
```

## 4. Executar

```bash
npm run dev
```

API: `http://localhost:3333`

Documentação Swagger: `http://localhost:3333/docs`

Health check: `GET /health`

## Recursos

| Recurso | Prefixo |
|---|---|
| UFs | `/api/v1/ufs` |
| Cidades | `/api/v1/cidades` |
| Empresas | `/api/v1/empresas` |
| Categorias | `/api/v1/categorias` |
| Itens | `/api/v1/itens` |
| Pratos | `/api/v1/pratos` |
| Prato/Itens | `/api/v1/prato-itens` |

Todos possuem operações de criação, consulta individual, listagem paginada, atualização e exclusão.

## Relacionamentos demonstrados

- `UF 1:N Cidades`
- `Cidade 1:N Empresas`
- `Empresa 1:N Categorias`
- `Empresa 1:N Itens`
- `Categoria 1:N Itens`
- `Empresa 1:N Pratos`
- `Prato N:N Itens` por meio de `prato_itens`

## Observação sobre UUID

O modelo ER informa `uuid`. Como o projeto utiliza MySQL, os UUIDs são armazenados como `varchar(36)` e gerados pela aplicação com `crypto.randomUUID()`. Essa decisão mantém a representação legível e compatível com o modelo solicitado.

## Testes

A suíte incluída verifica o comportamento do health check sem exigir conexão com o banco:

```bash
npm test
```

## Scripts

- `npm run dev` — desenvolvimento com hot reload
- `npm run build` — compilação TypeScript
- `npm start` — execução da versão compilada
- `npm run check` — verificação de tipos
- `npm run db:generate` — geração de migration
- `npm run db:migrate` — aplicação de migrations
- `npm run db:push` — sincronização direta do schema
- `npm run db:studio` — Drizzle Studio
