CREATE TABLE `ufs` (
  `id` varchar(36) NOT NULL,
  `sigla` varchar(2) NOT NULL,
  `nome` varchar(100) NOT NULL,
  CONSTRAINT `ufs_pk` PRIMARY KEY (`id`),
  CONSTRAINT `ufs_sigla_unique` UNIQUE (`sigla`)
);

CREATE TABLE `cidades` (
  `id` varchar(36) NOT NULL,
  `uf_id` varchar(36) NOT NULL,
  `nome` varchar(150) NOT NULL,
  CONSTRAINT `cidades_pk` PRIMARY KEY (`id`),
  CONSTRAINT `cidades_uf_fk` FOREIGN KEY (`uf_id`) REFERENCES `ufs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX `cidades_uf_id_idx` (`uf_id`)
);

CREATE TABLE `empresas` (
  `id` varchar(36) NOT NULL,
  `cidade_id` varchar(36) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cnpj` varchar(14),
  `ativo` boolean NOT NULL DEFAULT true,
  CONSTRAINT `empresas_pk` PRIMARY KEY (`id`),
  CONSTRAINT `empresas_cidade_fk` FOREIGN KEY (`cidade_id`) REFERENCES `cidades` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `empresas_cnpj_unique` UNIQUE (`cnpj`),
  INDEX `empresas_cidade_id_idx` (`cidade_id`)
);

CREATE TABLE `categorias` (
  `id` varchar(36) NOT NULL,
  `empresa_id` varchar(36) NOT NULL,
  `nome` varchar(100) NOT NULL,
  CONSTRAINT `categorias_pk` PRIMARY KEY (`id`),
  CONSTRAINT `categorias_empresa_fk` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX `categorias_empresa_id_idx` (`empresa_id`)
);

CREATE TABLE `itens` (
  `id` varchar(36) NOT NULL,
  `empresa_id` varchar(36) NOT NULL,
  `categoria_id` varchar(36) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `ativo` boolean NOT NULL DEFAULT true,
  CONSTRAINT `itens_pk` PRIMARY KEY (`id`),
  CONSTRAINT `itens_empresa_fk` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `itens_categoria_fk` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX `itens_empresa_id_idx` (`empresa_id`),
  INDEX `itens_categoria_id_idx` (`categoria_id`)
);

CREATE TABLE `pratos` (
  `id` varchar(36) NOT NULL,
  `empresa_id` varchar(36) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `descricao` text,
  `preco` decimal(10,2) NOT NULL,
  `ativo` boolean NOT NULL DEFAULT true,
  CONSTRAINT `pratos_pk` PRIMARY KEY (`id`),
  CONSTRAINT `pratos_empresa_fk` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX `pratos_empresa_id_idx` (`empresa_id`)
);

CREATE TABLE `prato_itens` (
  `id` varchar(36) NOT NULL,
  `prato_id` varchar(36) NOT NULL,
  `item_id` varchar(36) NOT NULL,
  CONSTRAINT `prato_itens_pk` PRIMARY KEY (`id`),
  CONSTRAINT `prato_itens_prato_fk` FOREIGN KEY (`prato_id`) REFERENCES `pratos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `prato_itens_item_fk` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `prato_itens_prato_item_unique` UNIQUE (`prato_id`, `item_id`),
  INDEX `prato_itens_prato_id_idx` (`prato_id`),
  INDEX `prato_itens_item_id_idx` (`item_id`)
);
